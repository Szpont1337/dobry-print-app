SZABLON DO DRUKU — Ulotki (drukalo.pl)
================================================

Zawartość:
  • ulotki.pdf — szablon ze spadami, jedna strona na format

Parametry przygotowania pliku:
  • Spad (bleed): 3 mm z każdej strony
  • Margines bezpieczny: 5 mm od linii cięcia
  • Tryb koloru: CMYK
  • Rozdzielczość grafik: 300 DPI
  • Czcionki: zamienione na krzywe lub osadzone

Formaty w pliku:
  • 74 × 105 mm: 74 × 105 mm (netto), 80 × 111 mm (brutto ze spadem)
  • 100 × 210 mm: 100 × 210 mm (netto), 106 × 216 mm (brutto ze spadem)
  • 105 × 148 mm: 105 × 148 mm (netto), 111 × 154 mm (brutto ze spadem)
  • 148 × 210 mm: 148 × 210 mm (netto), 154 × 216 mm (brutto ze spadem)
  • 210 × 297 mm: 210 × 297 mm (netto), 216 × 303 mm (brutto ze spadem)
  • 297 × 420 mm: 297 × 420 mm (netto), 303 × 426 mm (brutto ze spadem)

Oznaczenia na szablonie:
  • linia magenta  = linia cięcia (format netto)
  • linia cyan (kreskowana) = margines bezpieczny (tu trzymaj tekst i logo)
  • znaczniki w narożnikach = pasery cięcia
  • warstwę/tekst pomocniczy usuń przed wysłaniem pliku do druku

Gotowy plik wgrasz w konfiguratorze na https://drukalo.pl/produkty/ulotki
