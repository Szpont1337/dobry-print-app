SZABLON DO DRUKU — Wizytówki (drukalo.pl)
================================================

Zawartość:
  • wizytowki.pdf — szablon ze spadami, jedna strona na format

Parametry przygotowania pliku:
  • Spad (bleed): 3 mm z każdej strony
  • Margines bezpieczny: 5 mm od linii cięcia
  • Tryb koloru: CMYK
  • Rozdzielczość grafik: 300 DPI
  • Czcionki: zamienione na krzywe lub osadzone

Formaty w pliku:
  • 85 × 55 mm: 85 × 55 mm (netto), 91 × 61 mm (brutto ze spadem)
  • 90 × 50 mm: 90 × 50 mm (netto), 96 × 56 mm (brutto ze spadem)

Oznaczenia na szablonie:
  • linia magenta  = linia cięcia (format netto)
  • linia cyan (kreskowana) = margines bezpieczny (tu trzymaj tekst i logo)
  • znaczniki w narożnikach = pasery cięcia
  • warstwę/tekst pomocniczy usuń przed wysłaniem pliku do druku

Gotowy plik wgrasz w konfiguratorze na https://drukalo.pl/produkty/wizytowki
