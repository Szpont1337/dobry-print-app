SZABLON DO DRUKU — Plakaty (drukalo.pl)
================================================

Zawartość:
  • plakaty.pdf — szablon ze spadami, jedna strona na format

Parametry przygotowania pliku:
  • Spad (bleed): 3 mm z każdej strony
  • Margines bezpieczny: 5 mm od linii cięcia
  • Tryb koloru: CMYK
  • Rozdzielczość grafik: 300 DPI
  • Czcionki: zamienione na krzywe lub osadzone

Formaty w pliku:
  • 297 × 420 mm: 297 × 420 mm (netto), 303 × 426 mm (brutto ze spadem)
  • 420 × 594 mm: 420 × 594 mm (netto), 426 × 600 mm (brutto ze spadem)
  • 594 × 841 mm: 594 × 841 mm (netto), 600 × 847 mm (brutto ze spadem)
  • 841 × 1189 mm: 841 × 1189 mm (netto), 847 × 1195 mm (brutto ze spadem)
  • 707 × 1000 mm: 707 × 1000 mm (netto), 713 × 1006 mm (brutto ze spadem)

Oznaczenia na szablonie:
  • linia magenta  = linia cięcia (format netto)
  • linia cyan (kreskowana) = margines bezpieczny (tu trzymaj tekst i logo)
  • znaczniki w narożnikach = pasery cięcia
  • warstwę/tekst pomocniczy usuń przed wysłaniem pliku do druku

Gotowy plik wgrasz w konfiguratorze na https://drukalo.pl/produkty/plakaty
